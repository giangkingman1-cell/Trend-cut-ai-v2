# TREND CUT AI V2.3.0

Android offline video cutting/assembly prototype built with Kotlin + AndroidX Media3 Transformer.

## Version 2.3.0
- Select one source video and preview it locally.
- Local heuristic frame scoring remains available (brightness, tonal spread, edge detail and frame-to-frame change); it is not semantic AI.
- Manually define up to three time ranges from the same source video and concatenate them in order.
- Export with original aspect ratio, vertical 9:16, horizontal 16:9 or square 1:1. The selected social ratios use center crop to fill the frame.
- Exported MP4 is saved under Movies/TREND CUT AI.

## Limitations
- No neural visual understanding, object/person recognition, Vietnamese speech recognition, automatic subtitles, music-bed mixing, transitions, speed controls or draggable timeline.
- Multiple segments must come from the same selected source video.
- Center crop can cut off subjects near frame edges; review output before publishing.
- Requires Android 10+ (minSdk 29).

## Build
Use GitHub Actions workflow `.github/workflows/build-v2-3.yml` and download the APK from the Actions artifact. The APK has not been claimed tested on every device; test on the target phone before relying on it.
