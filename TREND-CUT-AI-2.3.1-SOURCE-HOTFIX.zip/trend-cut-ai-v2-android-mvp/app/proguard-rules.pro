# No minification in the debug MVP build.
