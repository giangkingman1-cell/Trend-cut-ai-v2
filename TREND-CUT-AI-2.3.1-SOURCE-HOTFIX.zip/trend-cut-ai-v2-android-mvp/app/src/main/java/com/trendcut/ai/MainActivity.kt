package com.trendcut.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.effect.Presentation
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

@UnstableApi
class MainActivity : AppCompatActivity() {
    private val bg = 0xFF090D18.toInt()
    private val panel = 0xFF141B2B.toInt()
    private val muted = 0xFF98A4BA.toInt()
    private val accent = 0xFF9B8CFF.toInt()
    private val mint = 0xFF47D7C2.toInt()
    private val worker = Executors.newSingleThreadExecutor()

    private var videoUri: Uri? = null
    private var durationMs: Long = 0L
    private var player: ExoPlayer? = null
    private var busy = false

    private lateinit var playerHost: FrameLayout
    private lateinit var fileLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var segmentInputs: List<EditText>
    private lateinit var aspectSpinner: Spinner
    private lateinit var promptInput: EditText
    private lateinit var analyzeButton: Button
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var scoreLabel: TextView

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            loadVideo(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        scroll.addView(content)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "TREND CUT  /  AI V2.3"
            textSize = 19f; setTextColor(-1); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val offline = TextView(this).apply {
            text = "● OFFLINE"
            textSize = 10f; setTextColor(mint); setPadding(dp(10), dp(6), dp(10), dp(6))
            setBackgroundColor(0xFF17332F.toInt())
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(offline)
        content.addView(top)
        content.addView(text("Dựng video nhanh. Dữ liệu ở lại trên máy.", 13f, muted).apply { setPadding(0, dp(7), 0, dp(17)) })

        val importButton = button("＋  CHỌN VIDEO", accent, bg)
        content.addView(importButton, matchWrap())
        importButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        fileLabel = text("Chưa có video được chọn", 12f, muted).apply { setPadding(0, dp(9), 0, dp(12)) }
        content.addView(fileLabel)

        playerHost = FrameLayout(this).apply {
            setBackgroundColor(0xFF05070D.toInt())
        }
        content.addView(playerHost, LinearLayout.LayoutParams(-1, dp(205)))

        content.addView(section("01  /  Ý TƯỞNG DỰNG"))
        promptInput = EditText(this).apply {
            hint = "Ví dụ: vlog chạy xe, nhịp nhanh, giữ cảnh đẹp và chuyển động..."
            setHintTextColor(0xFF71809A.toInt()); setTextColor(-1); textSize = 14f
            setPadding(dp(13), dp(13), dp(13), dp(13)); minLines = 2; maxLines = 3
            gravity = Gravity.TOP
            setBackgroundColor(panel)
        }
        content.addView(promptInput, matchWrap())
        content.addView(text("Bản hiện tại phân tích hình ảnh trực tiếp trên điện thoại bằng thuật toán cục bộ; không gửi video lên mạng.", 11f, muted).apply { setPadding(0, dp(8), 0, dp(12)) })

        analyzeButton = button("✦  PHÂN TÍCH & CHỌN ĐOẠN HAY", mint, bg)
        content.addView(analyzeButton, matchWrap())
        analyzeButton.setOnClickListener { analyzeVideo() }
        scoreLabel = text("Chưa phân tích video", 12f, muted).apply { setPadding(0, dp(10), 0, dp(8)) }
        content.addView(scoreLabel)

        content.addView(section("02  /  CÁC PHÂN ĐOẠN"))
        val trimRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        startInput = numberField("Bắt đầu (giây)", "0")
        endInput = numberField("Kết thúc (giây)", "0")
        trimRow.addView(startInput, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        trimRow.addView(endInput, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(8) })
        content.addView(trimRow)
        content.addView(text("Đoạn 1 là đoạn chính. Có thể thêm tối đa 2 đoạn khác; để trống nếu không dùng.", 11f, muted).apply { setPadding(0, dp(7), 0, dp(8)) })
        segmentInputs = (1..2).map { index ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val from = numberField("Đoạn ${index + 1} · từ giây", "")
            val to = numberField("Đến giây", "")
            row.addView(from, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) })
            row.addView(to, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(8) })
            content.addView(row, matchWrap())
            listOf(from, to)
        }.flatten()
        content.addView(section("03  /  TỶ LỆ KHUNG HÌNH"))
        aspectSpinner = Spinner(this)
        val ratios = listOf("Giữ nguyên tỷ lệ gốc", "Dọc 9:16 · TikTok/Reels", "Ngang 16:9 · YouTube", "Vuông 1:1")
        aspectSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ratios)
        content.addView(aspectSpinner, matchWrap())
        content.addView(text("Chế độ dọc/ngang sẽ crop giữa khung hình để lấp đầy tỷ lệ đã chọn; hãy kiểm tra chủ thể không bị cắt.", 11f, muted).apply { setPadding(0, dp(7), 0, dp(12)) })

        exportButton = button("⇧  GHÉP & XUẤT MP4", accent, bg)
        content.addView(exportButton, matchWrap())
        exportButton.setOnClickListener { exportVideo() }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE; progressTintList = android.content.res.ColorStateList.valueOf(mint)
        }
        content.addView(progress, LinearLayout.LayoutParams(-1, dp(5)).apply { topMargin = dp(12) })
        statusLabel = text("Sẵn sàng · Xử lý cục bộ", 12f, muted).apply { setPadding(0, dp(10), 0, 0) }
        content.addView(statusLabel)

        content.addView(section("GIỚI HẠN BẢN 2.3.0"))
        content.addView(text("Đã có: chọn video, chấm điểm hình ảnh cơ bản, cắt/ghép tối đa 3 đoạn từ cùng một video, xuất tỷ lệ 9:16 / 16:9 / 1:1. Chưa có AI hiểu ngữ nghĩa, nhận diện người/vật thể, phụ đề tự động, nhạc nền nhiều track, hiệu ứng chuyển cảnh hoặc timeline kéo thả.", 11f, muted).apply { setPadding(0, 0, 0, dp(12)) })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadVideo(uri: Uri) {
        stopPlayer()
        videoUri = uri
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            val name = queryName(uri) ?: "Video đã chọn"
            fileLabel.text = "$name  ·  ${formatTime(durationMs)}"
            startInput.setText("0")
            endInput.setText(String.format(Locale.US, "%.1f", durationMs / 1000.0))
            segmentInputs.forEach { it.setText("") }
            player = ExoPlayer.Builder(this).build().also { exo ->
                val view = PlayerView(this).apply { this.player = exo; useController = true }
                playerHost.removeAllViews()
                playerHost.addView(view, FrameLayout.LayoutParams(-1, -1))
                exo.setMediaItem(MediaItem.fromUri(uri)); exo.prepare()
            }
            statusLabel.text = "Đã nạp video · ${formatTime(durationMs)}"
            scoreLabel.text = "Sẵn sàng phân tích"
        } catch (e: Exception) {
            toast("Không đọc được video: ${e.message ?: "lỗi định dạng"}")
        }
    }

    private data class FrameScore(val second: Int, val score: Double, val motion: Double, val sceneChange: Double)

    private fun analyzeVideo() {
        val uri = videoUri
        if (uri == null) { toast("Hãy chọn video trước"); return }
        if (busy) return
        busy = true
        analyzeButton.isEnabled = false
        val prompt = promptInput.text.toString().lowercase(Locale.ROOT)
        statusLabel.text = "Đang phân tích khung hình trên thiết bị..."
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        worker.execute {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(this, uri)
                val seconds = max(1, (durationMs / 1000L).toInt())
                val scores = ArrayList<FrameScore>()
                // Sample at most ~100 frames; keep only one small previous frame for motion analysis.
                val stride = max(1, seconds / 100)
                var previous: Bitmap? = null
                var t = 0
                while (t <= seconds) {
                    val frame = if (Build.VERSION.SDK_INT >= 27) {
                        retriever.getScaledFrameAtTime(t * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 96, 54)
                    } else {
                        retriever.getFrameAtTime(t * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }
                    if (frame != null) {
                        val visual = qualityScore(frame)
                        val motion = previous?.let { frameDifference(it, frame) } ?: 0.0
                        val change = previous?.let { sceneDifference(it, frame) } ?: 0.0
                        scores.add(FrameScore(t, visual, motion, change))
                        previous?.recycle()
                        previous = Bitmap.createScaledBitmap(frame, 64, 36, true)
                        frame.recycle()
                    }
                    t += stride
                }
                previous?.recycle()
                retriever.release()
                if (scores.isEmpty()) throw IllegalStateException("Không trích xuất được khung hình")

                val requested = when {
                    prompt.contains("3 giây") || prompt.contains("3s") -> 3
                    prompt.contains("5 giây") || prompt.contains("5s") -> 5
                    prompt.contains("10 giây") || prompt.contains("10s") -> 10
                    prompt.contains("15 giây") || prompt.contains("15s") || prompt.contains("tiktok") || prompt.contains("reel") || prompt.contains("short") -> 15
                    prompt.contains("30 giây") || prompt.contains("30s") -> 30
                    prompt.contains("intro") || prompt.contains("mở đầu") || prompt.contains("hook") -> 8
                    prompt.contains("vlog") || prompt.contains("phượt") || prompt.contains("review") -> 22
                    else -> 18
                }
                val clipSeconds = min(seconds.toDouble(), requested.toDouble()).toInt().coerceAtLeast(1)
                var bestStart = 0
                var bestScore = Double.NEGATIVE_INFINITY
                val lastStart = max(0, seconds - clipSeconds)
                for (start in 0..lastStart step max(1, stride)) {
                    val window = scores.filter { it.second >= start && it.second <= start + clipSeconds }
                    if (window.isNotEmpty()) {
                        val visualMean = window.map { it.score }.average()
                        val motionMean = window.map { it.motion }.average()
                        val sceneMean = window.map { it.sceneChange }.average()
                        // Vlog/action prompts reward visible movement; calm/story prompts favor stable scenes.
                        val actionIntent = prompt.contains("hành động") || prompt.contains("chuyển động") || prompt.contains("chạy") || prompt.contains("phượt") || prompt.contains("action")
                        val motionWeight = if (actionIntent) 0.24 else 0.10
                        val combined = visualMean * (1.0 - motionWeight) + motionMean * motionWeight + sceneMean * 0.06
                        if (combined > bestScore) { bestScore = combined; bestStart = start }
                    }
                }
                val outStart = bestStart
                val outEnd = min(seconds, bestStart + clipSeconds)
                runOnUiThread {
                    startInput.setText(outStart.toString())
                    endInput.setText(outEnd.toString())
                    segmentInputs.forEach { it.setText("") }
                    val avgMotion = scores.filter { it.second in outStart..outEnd }.map { it.motion }.average().takeIf { it.isFinite() } ?: 0.0
                    scoreLabel.text = "Đề xuất ${outStart}s → ${outEnd}s  ·  ${scores.size} mẫu · điểm tổng ${String.format(Locale.US, "%.2f", bestScore)} · chuyển động ${String.format(Locale.US, "%.2f", avgMotion)}"
                    statusLabel.text = "Phân tích xong · Không dùng Internet"
                    progress.visibility = View.GONE; progress.isIndeterminate = false
                    analyzeButton.isEnabled = true; busy = false
                    player?.seekTo(outStart * 1000L)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE; progress.isIndeterminate = false
                    analyzeButton.isEnabled = true; busy = false
                    statusLabel.text = "Phân tích không thành công"
                    toast(e.message ?: "Lỗi phân tích")
                }
            }
        }
    }

    // Normalized frame-to-frame pixel difference. This detects visible motion/camera changes,
    // but does not identify objects or understand semantic content.
    private fun frameDifference(a: Bitmap, b: Bitmap): Double {
        val w = 32; val h = 18
        val aa = Bitmap.createScaledBitmap(a, w, h, true)
        val bb = Bitmap.createScaledBitmap(b, w, h, true)
        val pa = IntArray(w * h); val pb = IntArray(w * h)
        aa.getPixels(pa, 0, w, 0, 0, w, h); bb.getPixels(pb, 0, w, 0, 0, w, h)
        var diff = 0.0
        for (i in pa.indices) {
            val ya = 0.2126 * (pa[i] shr 16 and 255) + 0.7152 * (pa[i] shr 8 and 255) + 0.0722 * (pa[i] and 255)
            val yb = 0.2126 * (pb[i] shr 16 and 255) + 0.7152 * (pb[i] shr 8 and 255) + 0.0722 * (pb[i] and 255)
            diff += kotlin.math.abs(ya - yb)
        }
        if (aa !== a) aa.recycle(); if (bb !== b) bb.recycle()
        return (diff / pa.size / 64.0).coerceIn(0.0, 1.0)
    }

    private fun sceneDifference(a: Bitmap, b: Bitmap): Double = (frameDifference(a, b) * 1.6).coerceIn(0.0, 1.0)

    // A lightweight visual heuristic: exposure balance, tonal spread and local edge energy.
    // This is deterministic on-device analysis, not a neural-network model.
    private fun qualityScore(source: Bitmap): Double {
        val w = 48; val h = 27
        val bitmap = Bitmap.createScaledBitmap(source, w, h, true)
        val px = IntArray(w * h); bitmap.getPixels(px, 0, w, 0, 0, w, h)
        var sum = 0.0; var sumSq = 0.0; var edge = 0.0
        val lum = DoubleArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16 and 255).toDouble(); val g = (c shr 8 and 255).toDouble(); val b = (c and 255).toDouble()
            val y = 0.2126 * r + 0.7152 * g + 0.0722 * b
            lum[i] = y; sum += y; sumSq += y * y
        }
        val mean = sum / px.size
        val variance = max(0.0, sumSq / px.size - mean * mean)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            edge += kotlin.math.abs(lum[i] - lum[i - 1]) + kotlin.math.abs(lum[i] - lum[i - w])
        }
        val exposure = 1.0 - min(1.0, kotlin.math.abs(mean - 128.0) / 128.0)
        val texture = min(1.0, sqrt(variance) / 72.0)
        val detail = min(1.0, (edge / ((w - 2) * (h - 2))) / 42.0)
        if (bitmap !== source) bitmap.recycle()
        return exposure * 0.45 + texture * 0.30 + detail * 0.25
    }

    private fun exportVideo() {
        val uri = videoUri ?: run { toast("Hãy chọn video trước"); return }
        if (busy) return
        val ranges = ArrayList<Pair<Long, Long>>()
        val fields = listOf(startInput, endInput) + segmentInputs
        for (i in 0 until 3) {
            val fromText = fields[i * 2].text.toString().trim()
            val toText = fields[i * 2 + 1].text.toString().trim()
            if (fromText.isEmpty() && toText.isEmpty()) continue
            if (fromText.isEmpty() || toText.isEmpty()) { toast("Hãy nhập đủ thời gian bắt đầu và kết thúc của đoạn ${i + 1}"); return }
            val from = (fromText.toDoubleOrNull() ?: -1.0).let { (it * 1000).toLong() }
            val to = (toText.toDoubleOrNull() ?: -1.0).let { (it * 1000).toLong() }
            if (from < 0 || to > durationMs || to <= from || to - from < 500) {
                toast("Mốc cắt đoạn ${i + 1} không hợp lệ"); return
            }
            ranges.add(from to to)
        }
        if (ranges.isEmpty()) { toast("Hãy nhập ít nhất một đoạn video"); return }
        busy = true; exportButton.isEnabled = false; analyzeButton.isEnabled = false
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        statusLabel.text = "Đang ghép ${ranges.size} đoạn và xuất MP4..."
        val out = File(cacheDir, "trendcut_${System.currentTimeMillis()}.mp4")
        try {
            val aspect = when (aspectSpinner.selectedItemPosition) {
                1 -> 9f / 16f
                2 -> 16f / 9f
                3 -> 1f
                else -> 0f
            }
            val editedItems = ranges.map { (from, to) ->
                val clip = MediaItem.Builder().setUri(uri)
                    .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(from).setEndPositionMs(to).build()).build()
                val builder = EditedMediaItem.Builder(clip)
                if (aspect > 0f) {
                    val presentation = Presentation.createForAspectRatio(aspect, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
                    builder.setEffects(Effects(emptyList(), listOf(presentation)))
                }
                builder.build()
            }
            // Media3 1.5.1 does not expose a no-argument Builder constructor.
            // Use the list constructor supported by this pinned dependency.
            @Suppress("DEPRECATION")
            val sequence = EditedMediaItemSequence.Builder(editedItems).build()
            val composition = Composition.Builder(listOf(sequence)).build()
            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        worker.execute {
                            try {
                                val saved = saveToGallery(out)
                                runOnUiThread {
                                    statusLabel.text = "Đã ghép ${ranges.size} đoạn · MP4 đã lưu"
                                    toast("Xuất thành công · ${saved ?: "Movies/TREND CUT AI"}")
                                    finishExportUi()
                                }
                            } catch (e: Exception) {
                                runOnUiThread { statusLabel.text = "Xuất xong nhưng không lưu được"; toast(e.message ?: "Lỗi lưu tệp"); finishExportUi() }
                            } finally { out.delete() }
                        }
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        out.delete()
                        runOnUiThread { statusLabel.text = "Ghép/xuất video thất bại"; toast(exportException.localizedMessage ?: "Lỗi mã hóa"); finishExportUi() }
                    }
                }).build()
            transformer.start(composition, out.absolutePath)
        } catch (e: Exception) {
            out.delete(); statusLabel.text = "Không thể bắt đầu ghép video"; toast(e.message ?: "Lỗi xuất"); finishExportUi()
        }
    }

    private fun finishExportUi() {
        busy = false; exportButton.isEnabled = true; analyzeButton.isEnabled = true
        progress.visibility = View.GONE; progress.isIndeterminate = false
    }

    private fun saveToGallery(file: File): String? {
        val name = "TREND_CUT_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TREND CUT AI")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Không tạo được tệp trong thư viện")
        try {
            contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { input -> input.copyTo(output) } }
                ?: throw IllegalStateException("Không mở được tệp đầu ra")
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
            }
        } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
        return name
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun stopPlayer() { player?.release(); player = null; playerHost.removeAllViews() }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { stopPlayer(); worker.shutdown(); super.onDestroy() }

    private fun text(value: String, size: Float, color: Int) = TextView(this).apply { text = value; textSize = size; setTextColor(color) }
    private fun section(value: String) = text(value, 11f, mint).apply { setPadding(0, dp(20), 0, dp(10)); letterSpacing = 0.08f }
    private fun button(value: String, color: Int, textColor: Int) = Button(this).apply {
        text = value; isAllCaps = false; textSize = 14f; setTextColor(textColor)
        backgroundTintList = android.content.res.ColorStateList.valueOf(color)
        minHeight = dp(52); typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private fun numberField(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setHintTextColor(muted); setTextColor(-1); setText(value)
        textSize = 14f; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(panel)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun formatTime(ms: Long): String { val sec = ms / 1000; return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60) }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
