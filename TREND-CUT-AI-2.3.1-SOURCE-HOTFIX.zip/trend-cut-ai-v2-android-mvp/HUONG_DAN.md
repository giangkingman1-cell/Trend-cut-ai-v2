# Hướng dẫn TREND CUT AI V2.3.0

1. Chọn một video nguồn và xem trước.
2. Nhấn Phân tích để ứng dụng chấm điểm khung hình bằng thuật toán cục bộ. Kết quả chỉ là gợi ý hình ảnh, không phải AI nhận diện nội dung.
3. Đoạn 1 lấy từ kết quả phân tích. Có thể sửa hai mốc giây.
4. Nhập thêm thời gian bắt đầu/kết thúc cho đoạn 2 và 3 nếu muốn ghép. Để trống cả hai ô của đoạn không dùng.
5. Chọn tỷ lệ gốc, dọc 9:16, ngang 16:9 hoặc vuông 1:1.
6. Nhấn Ghép & Xuất MP4. File được lưu trong Movies/TREND CUT AI.

Lưu ý: Các đoạn lấy từ cùng một video. Tỷ lệ mạng xã hội dùng crop giữa khung hình; có thể cắt mất vật thể ở mép. Bản này chưa có phụ đề tự động, nhạc nền nhiều track, AI hiểu ngữ nghĩa hay timeline kéo thả.
