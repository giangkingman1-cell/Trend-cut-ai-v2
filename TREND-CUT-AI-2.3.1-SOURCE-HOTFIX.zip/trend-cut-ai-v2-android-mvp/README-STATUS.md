# Trạng thái bản 2.3.1

Đây là source hotfix cho lỗi khởi tạo Media3 `EditedMediaItemSequence.Builder`.

**Chưa phải bản nâng cấp đầy đủ** theo yêu cầu: chưa có multi-clip timeline, split/delete/reorder clip, audio track, subtitle/text overlay, transitions, undo/redo hoặc AI semantic. Không sử dụng mô tả các chức năng này như thể đã có.

Build yêu cầu Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, JDK 17 và Media3 1.5.1. Cần build và kiểm thử trên máy có Android SDK trước khi phát hành APK.
