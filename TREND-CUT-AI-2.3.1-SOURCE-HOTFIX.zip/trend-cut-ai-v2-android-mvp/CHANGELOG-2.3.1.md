# TREND CUT AI 2.3.1 — hotfix nguồn

## Đã sửa
- Sửa cách khởi tạo `EditedMediaItemSequence` tương thích API Media3 1.5.1: bỏ constructor Builder() không tồn tại, dùng constructor nhận danh sách `EditedMediaItem`.
- Tăng `versionCode` từ 5 lên 6 và `versionName` từ 2.3.0 lên 2.3.1.

## Phạm vi hiện tại (không quảng cáo quá khả năng)
Đây là bản vá lỗi build trong luồng ghép/xuất video, không phải bản viết lại đầy đủ của trình biên tập. Ứng dụng hiện vẫn chỉ nhận một video nguồn, cắt/ghép tối đa 3 đoạn từ cùng video và xuất MP4 theo tỷ lệ khung hình. Chấm điểm hình ảnh là heuristic cục bộ, không phải AI hiểu ngữ nghĩa.

## Kiểm chứng
- Đã kiểm tra mã nguồn và xác nhận đoạn Builder() sai đã được thay thế.
- Chưa build APK và chưa chạy kiểm thử trên Android trong môi trường tạo bản này (không có Android SDK/Gradle wrapper khả dụng). Không coi đây là bản APK đã kiểm thử.
