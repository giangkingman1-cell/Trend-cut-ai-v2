# Đưa bản nâng cấp lên GitHub Actions

File này được đóng gói với đúng đường dẫn dự án mà workflow hiện có đang chờ.

1. Vào repository `giangkingman1-cell/Trend-cut-ai-v2` → tab **Code**.
2. Xóa file ZIP cũ `TREND-CUT-AI-V2-source-for-github.zip` và commit thay đổi.
3. Chọn **Add file → Upload files**, tải lên file mới cùng tên `TREND-CUT-AI-V2-source-for-github.zip`, rồi commit vào nhánh `main`.
4. Mở tab **Actions**. Workflow `Build TREND CUT AI APK` sẽ tự chạy khi ZIP mới được push.
5. Khi run thành công, mở run mới nhất → mục **Artifacts** → tải `TREND-CUT-AI-V2-APK`, giải nén ZIP để lấy `app-debug.apk`.

Lưu ý: thao tác xóa ZIP cũ có thể tạo một lần chạy thất bại vì chưa có ZIP; lần chạy sau khi tải ZIP mới lên mới là lần cần xem.
