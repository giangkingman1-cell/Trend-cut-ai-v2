package com.trendcut.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private var transformer: Transformer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            playVideo(uri)
            status.text = "Đã chọn video. Nhập thời điểm cắt rồi xuất MP4."
            exportButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        exportButton.isEnabled = false
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(0xFF101820.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "TREND CUT AI V2"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "OFFLINE VIDEO EDITOR · MVP 0.1"
            textSize = 12f
            setTextColor(0xFF8FA3B8.toInt())
            setPadding(0, dp(4), 0, dp(14))
        }
        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
            setBackgroundColor(0xFF000000.toInt())
        }
        val pickButton = button("CHỌN VIDEO") { pickVideo.launch(arrayOf("video/*")) }
        val labels = TextView(this).apply {
            text = "CẮT VIDEO (GIÂY)"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(18), 0, dp(8))
        }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startInput = edit("Bắt đầu", "0")
        endInput = edit("Kết thúc", "30")
        fields.addView(startInput, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) })
        fields.addView(endInput, LinearLayout.LayoutParams(0, dp(52), 1f))
        val previewButton = button("XEM ĐOẠN ĐÃ CHỌN") { previewTrim() }
        exportButton = button("XUẤT VIDEO MP4") { exportTrim() }
        status = TextView(this).apply {
            text = "Chưa có video. Chọn một video trong điện thoại để bắt đầu."
            textSize = 13f
            setTextColor(0xFFB7C6D6.toInt())
            setPadding(0, dp(14), 0, dp(8))
        }
        val note = TextView(this).apply {
            text = "Bản MVP hiện hỗ trợ chọn video, phát, cắt một đoạn và xuất MP4 offline. AI tự động dựng sẽ được tích hợp ở phiên bản tiếp theo."
            textSize = 12f
            setTextColor(0xFF8FA3B8.toInt())
            setPadding(0, dp(8), 0, dp(20))
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(playerView)
        content.addView(pickButton)
        content.addView(labels)
        content.addView(fields)
        content.addView(previewButton)
        content.addView(exportButton)
        content.addView(status)
        content.addView(note)
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun playVideo(uri: Uri) {
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = false
        }
    }

    private fun previewTrim() {
        val exo = player ?: return toast("Hãy chọn video trước")
        val start = startInput.text.toString().toDoubleOrNull() ?: 0.0
        val end = endInput.text.toString().toDoubleOrNull() ?: return toast("Thời điểm kết thúc không hợp lệ")
        if (start < 0 || end <= start) return toast("Khoảng cắt không hợp lệ")
        exo.seekTo((start * 1000).toLong())
        exo.playWhenReady = true
        status.text = "Đang xem trước từ ${start}s. Video sẽ tiếp tục phát; xuất MP4 sẽ dùng đúng khoảng cắt."
    }

    private fun exportTrim() {
        val uri = selectedUri ?: return toast("Hãy chọn video trước")
        val start = startInput.text.toString().toDoubleOrNull() ?: 0.0
        val end = endInput.text.toString().toDoubleOrNull() ?: return toast("Thời điểm kết thúc không hợp lệ")
        if (start < 0 || end <= start) return toast("Khoảng cắt không hợp lệ")
        val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!outputDir.exists()) outputDir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val output = File(outputDir, "TREND_CUT_$stamp.mp4")
        exportButton.isEnabled = false
        status.text = "Đang xuất video… Không đóng ứng dụng trong lúc xử lý."
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs((start * 1000).toLong())
            .setEndPositionMs((end * 1000).toLong())
            .build()
        val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
        val edited = EditedMediaItem.Builder(mediaItem).build()
        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        status.text = "Xuất thành công: ${output.absolutePath}"
                        exportButton.isEnabled = true
                        toast("Đã xuất MP4 thành công")
                    }
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    runOnUiThread {
                        status.text = "Lỗi xuất video: ${exportException.message ?: "Không xác định"}"
                        exportButton.isEnabled = true
                        toast("Xuất video thất bại")
                    }
                }
            }).build()
        try {
            transformer?.start(edited, output.absolutePath)
        } catch (e: Exception) {
            exportButton.isEnabled = true
            status.text = "Không thể bắt đầu xuất: ${e.message}"
        }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(10) }
    }

    private fun edit(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 16f
        setSingleLine(true)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFF8FA3B8.toInt())
        setPadding(dp(12), 0, dp(12), 0)
        setBackgroundColor(0xFF263442.toInt())
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        transformer?.cancel()
        super.onDestroy()
    }
}
