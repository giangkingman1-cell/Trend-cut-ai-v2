# Đưa TREND CUT AI V2 lên GitHub bằng điện thoại (không dùng Termux)

## 1. Tải và upload mã nguồn
1. Tải file `TREND-CUT-AI-V2-source-for-github.zip` về điện thoại.
2. Mở repository: https://github.com/giangkingman1-cell/Trend-cut-ai-v2
3. Chọn **Add file → Upload files**.
4. Chọn file ZIP vừa tải, kéo xuống bấm **Commit changes**.

## 2. Tạo workflow để GitHub tự build APK
1. Trong repository, chọn **Add file → Create new file**.
2. Ở ô tên file, nhập chính xác: `.github/workflows/build-apk.yml`
3. Mở file `build-apk.yml` đi kèm gói tải về, sao chép toàn bộ nội dung rồi dán vào GitHub.
4. Bấm **Commit changes**.

## 3. Tải APK
1. Mở tab **Actions** của repository.
2. Chọn workflow **Build TREND CUT AI APK**.
3. Chờ chạy xong và có dấu xanh **Success**.
4. Mở lần chạy đó, tìm **Artifacts**, tải `trend-cut-ai-debug-apk`.
5. Giải nén file artifact để lấy `app-debug.apk`.

Nếu build thất bại, gửi ảnh hoặc log lỗi ở cuối job `build` để sửa.

Lưu ý: Repository hiện đang Public. Mã nguồn và file ZIP được tải lên sẽ công khai. APK là bản debug thử nghiệm, chưa phải bản phát hành thương mại.
