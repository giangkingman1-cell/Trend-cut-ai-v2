# TREND CUT AI V2 — Android Offline MVP 0.1

Native Android starter app for local video selection, playback, trimming and MP4 export. The app declares no Internet permission and does not upload media.

## MVP features
- Pick a local video through Android's system document picker.
- Play the selected video with Media3 ExoPlayer.
- Set trim start/end positions in seconds.
- Preview from the selected start point.
- Export the selected range as MP4 using Media3 Transformer.
- Save output under the app-specific Movies folder (`Android/data/com.trendcut.ai/files/Movies`).

## Not included yet
- Qwen / llama.cpp local LLM.
- Automatic semantic scene selection.
- Whisper transcription.
- Automatic music beat matching.
- Multi-clip timeline, transitions, speed controls and advanced color grading.

These are deliberately deferred until the video import/trim/export path builds and is tested on the target phone.

## Build
GitHub Actions builds a debug APK on every push to `main` and on manual workflow dispatch. Open Actions, select **Build TREND CUT AI APK**, then download the `trend-cut-ai-debug-apk` artifact after a successful run.

## Toolchain
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Kotlin 2.0.21
- JDK 17
- compileSdk 35 / minSdk 26
- AndroidX Media3 1.5.1

This is a debug test build, not a Play Store release. Gradle dependencies are fetched during cloud build; the installed app itself has no Internet permission.
